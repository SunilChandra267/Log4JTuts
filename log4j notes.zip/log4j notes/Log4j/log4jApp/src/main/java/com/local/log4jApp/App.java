package com.local.log4jApp;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
	
public class App 
{
	public static void main( String[] args )
	{
		System.out.println("Program Strated..");
		String path = "D:/Files/Life.txt";
		try {
			System.out.println("Creating FileReader object");
			FileReader in = new FileReader(path);
			BufferedReader reader = new BufferedReader(in);
			System.out.println("The file reading started...");
			String line = "";
			while((line= reader.readLine())!= null){
				System.out.println(line);
			}
			reader.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Ended...");
	}
}
