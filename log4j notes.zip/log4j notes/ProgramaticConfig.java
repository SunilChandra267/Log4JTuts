package org.sunil.l4j;

import org.apache.log4j.Appender;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;

public class ProgramaticConfig {
	final static Logger LOG = Logger.getLogger(ProgramaticConfig.class);
	public static void main(String[] args) {
		Layout layout = new PatternLayout("%d{YYYY-MM-DD HH:mm:ss} %-5p %c{10}:%L - %m%n");
		
		Appender append = new ConsoleAppender(layout);
		
		LOG.addAppender(append);
		
		LOG.debug("in debug()");
		LOG.debug("inside another debug");
	}

}
